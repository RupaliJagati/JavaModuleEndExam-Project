package com.canteen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.dao.SelectDishDao;
import com.canteen.dto.SelectDish;




@Service
public class SelectDishServiceImple implements SelectDishService {

	@Autowired
	private SelectDishDao selectDishDao;
	@Override
	public void addDish(SelectDish selectDish) {
		selectDishDao.insertSelectDish(selectDish);
		
	}

	@Override
	public List<SelectDish> selectAllDish1(int selectDishId) {
		// TODO Auto-generated method stub
		return selectDishDao.selectAllDish(selectDishId);
	}

	/*@Override
	public void removeDish(int selectDishId) {
		// TODO Auto-generated method stub
		selectDishDao.deleteDishes(selectDishId);
	}*/
	
	
	
	

}
