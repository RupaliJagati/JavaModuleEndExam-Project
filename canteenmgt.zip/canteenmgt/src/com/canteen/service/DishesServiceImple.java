package com.canteen.service;

import java.util.List;

import org.springframework.stereotype.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.dao.DishesDao;
import com.canteen.dto.Dishes;

@Service
public class DishesServiceImple implements DishesService{

	@Autowired
	private DishesDao dishesDao; 
	
	@Override
	public void addDishes(Dishes dishes) {
		dishesDao.insertDishes(dishes);
		
	}

	@Override
	public void removeDishes(int dishId) {
		dishesDao.deleteDishes(dishId);
		
	}

	@Override
	public Dishes findDishes(int dishId) {
		return dishesDao.selectDishes(dishId);
	}

	@Override
	public void modifyDishes(Dishes dishes) {
		dishesDao.updateDishes(dishes);
		
	}

	@Override
	public List<Dishes> selectAll() {
		return dishesDao.selectAll();
	}

}
