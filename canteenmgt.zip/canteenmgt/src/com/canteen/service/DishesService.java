package com.canteen.service;
import java.util.List;

import com.canteen.dto.Dishes;
import com.canteen.dto.SelectDish;

public interface DishesService {
	
	
	
	
	
	
	void addDishes(Dishes dishes);
	void removeDishes(int dishId);
	Dishes findDishes(int dishId);
	void modifyDishes(Dishes dishes);
	
	List<Dishes> selectAll();

}





