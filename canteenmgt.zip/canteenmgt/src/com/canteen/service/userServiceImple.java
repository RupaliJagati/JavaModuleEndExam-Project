package com.canteen.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.dao.UserDao;
import com.canteen.dto.User;

@Service
public class userServiceImple implements UserService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public void addUser(User user) {
		userDao.insertUser(user);
	}

	@Override
	public boolean findUser(User user) {
		// TODO Auto-generated method stub
		return userDao.checkUser(user);
	}
	@Override
	public String forgotPassword(String userName) {
		return userDao.forgotPassword(userName);
	}

}

