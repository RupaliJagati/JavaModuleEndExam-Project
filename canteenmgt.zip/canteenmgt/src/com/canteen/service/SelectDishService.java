package com.canteen.service;

import java.util.List;

import com.canteen.dto.SelectDish;



public interface SelectDishService {
	void addDish(SelectDish selectDish);
	List<SelectDish> selectAllDish1(int selectDishId);
	//void removeDish(int selectDishId);
}
