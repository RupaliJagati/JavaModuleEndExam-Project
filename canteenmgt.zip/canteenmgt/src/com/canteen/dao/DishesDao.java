package com.canteen.dao;

import com.canteen.dto.Dishes;
import com.canteen.dto.SelectDish;

import java.util.List;

public interface DishesDao {
	
	
	
	
	
	void insertDishes(Dishes dishes);
	void deleteDishes(int dishId);
	Dishes selectDishes(int dishId);
	
	void updateDishes(Dishes dishes);
	List<Dishes> selectAll();
}
