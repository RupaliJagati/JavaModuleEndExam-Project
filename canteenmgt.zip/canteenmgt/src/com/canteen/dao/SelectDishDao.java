package com.canteen.dao;
import java.util.List;

import com.canteen.dto.SelectDish;

public interface SelectDishDao {
	void insertSelectDish(SelectDish selectDish);
	List<SelectDish> selectAllDish(int selectDishid);
	//void deleteDishes(int selectDishId);
}
