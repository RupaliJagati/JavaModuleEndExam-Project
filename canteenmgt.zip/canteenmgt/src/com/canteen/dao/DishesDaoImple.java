package com.canteen.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.canteen.dto.Dishes;
import com.canteen.dto.SelectDish;

@Repository
public class DishesDaoImple implements DishesDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertDishes(Dishes dishes) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(dishes);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}
		
	@Override
	public void deleteDishes(int dishId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Dishes(dishId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}


	
	
	
	
	
	
	
	@Override
	public Dishes selectDishes(int dishId) {
		Dishes dishes = hibernateTemplate.execute(new HibernateCallback<Dishes>() {

			@Override
			public Dishes doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Dishes di = (Dishes)session.get(Dishes.class,dishId);
				tr.commit();
				session.flush();
				session.close();
				return di;
			}
			
		});
		return dishes;
	}



	@Override
	public void updateDishes(Dishes dishes) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(dishes);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	

	@Override
	public List<Dishes> selectAll( ) {
		List<Dishes> dishList = hibernateTemplate.execute(new HibernateCallback<List<Dishes>>() {

			@Override
			public List<Dishes> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Dishes");
				//q.setInteger(0, userId);
				List<Dishes> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return dishList;
	}

}

