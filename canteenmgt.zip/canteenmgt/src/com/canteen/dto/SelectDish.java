/*package com.canteen.dto;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class SelectDish 
{
	@Id
	@GeneratedValue
	private int selectDishId;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToOne
	@JoinColumn(name="dishId")
	private Dishes dish;
	private int quantity;
	public SelectDish() {
		super();
	}
	public SelectDish(int selectDishId, User user, Dishes dish, int quantity) {
		super();
		this.selectDishId = selectDishId;
		this.user = user;
		this.dish = dish;
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "SelectDish [selectDishId=" + selectDishId + ", user=" + user + ", dish=" + dish + ", quantity="
				+ quantity + "]";
	}
	public int getSelectDishId() {
		return selectDishId;
	}
	public void setSelectDishId(int selectDishId) {
		this.selectDishId = selectDishId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Dishes getDish() {
		return dish;
	}
	
	public void setDish(Dishes dish) {
		this.dish = dish;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}*/
package com.canteen.dto;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class SelectDish 
{
	@Id
	@GeneratedValue
	private int selectDishId;
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToOne
	@JoinColumn(name="dishId")
	private Dishes dish;
	private int quantity;
	public SelectDish() {
		super();
	}
	public SelectDish(int selectDishId, User user, Dishes dish, int quantity) {
		super();
		this.selectDishId = selectDishId;
		this.user = user;
		this.dish = dish;
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "SelectDish [selectDishId=" + selectDishId + ", user=" + user + ", dish=" + dish + ", quantity="
				+ quantity + "]";
	}
	public int getSelectDishId() {
		return selectDishId;
	}
	public void setSelectDishId(int selectDishId) {
		this.selectDishId = selectDishId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Dishes getDish() {
		return dish;
	}
	public void setDish(Dishes dish) {
		this.dish = dish;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}



