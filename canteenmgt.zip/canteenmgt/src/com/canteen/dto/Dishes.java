package com.canteen.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Dish")
public class Dishes
{
	@Id
	@Column(name = "dish_id")
	@GeneratedValue
	private int dishId;
	@Column(name = "dish_name")
	private String dishName;
	@Column(name = "price")
	private int price;
	//private int userId;
	public Dishes() {
		
	}
	
	public Dishes(int dishId) {
		super();
		this.dishId = dishId;
	}

	public int getDishId() {
		return dishId;
	}
	public void setDishId(int dishId) {
		this.dishId = dishId;
	}
	public String getDishName() {
		return dishName;
	}
	
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Dishes [dishId=" + dishId + ", dishName=" + dishName + ", price=" + price + "]";
	}

	/*public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}*/
	
}
