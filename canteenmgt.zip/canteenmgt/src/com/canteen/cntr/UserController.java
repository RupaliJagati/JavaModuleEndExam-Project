package com.canteen.cntr;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.canteen.dto.Dishes;
import com.canteen.dto.User;
import com.canteen.service.DishesService;
import com.canteen.service.UserService;
import com.canteen.valid.UserValidator;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private DishesService dishesService;
	@Autowired
	private MailSender mailSender;


	
	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("user", new User());
		return "reg_form";
	}
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String register(User user,ModelMap map) {
		userService.addUser(user);
		return "login_form";
	}
	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLoginForm(ModelMap map)
	{
		map.put("user",new User());
		return "login_form";
		
	}

	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(User user,BindingResult result,ModelMap map,HttpSession session) {
		
		userValidator.validate(user, result);
		if(result.hasErrors()) {
			
			return "login_form";
		}
		System.out.println(user);
		boolean b = userService.findUser(user);
		if(b) {
			if(user.getUserName().equals("Admin")&& user.getUserPass().equals("111111")) {
				session.setAttribute("user", user);
				return "home";
			}
			else {
			session.setAttribute("user", user);
			
			return "user_Home";
			}
		}else {
			map.put("user", new User());
			return "login_form";
		}
	}
	
	/*@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepUserHomeForm(ModelMap map)
	{
		map.put("user",new User());
		return "user_Home";
		
	}*/
	@RequestMapping(value = "/dishes_list1.htm",method = RequestMethod.GET)
	public String allDishes(ModelMap map,HttpSession session) {
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Dishes> li = dishesService.selectAll();
		map.put("dishList", li);
		return "Home_List";
	}
	
	@RequestMapping(value = "/logout_stud.htm" , method = RequestMethod.GET)
	public String logoutStud(User user,ModelMap map , HttpSession session) {
		session.removeAttribute("user");
		return "login_form";
	}
	
//	Admin logout
	@RequestMapping(value = "/logout_admin.htm" , method = RequestMethod.GET)
	public String logoutAdmin(User user, ModelMap map , HttpSession session) {
	   session.removeAttribute("user");
		//session.invalidate();
		return "login_form";
	}
	
//	Routing to index page
	public static boolean routeProtected(HttpSession session) {
		Object obj = session.getAttribute("user");
		if(obj==null) {
			return false; 
		}
		return true;
	}
	//forgot passs
	@RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String userName,ModelMap map) {		
		String pass = userService.forgotPassword(userName);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("canteenmang@gmail.com");  
	        message.setTo(userName);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
			msg = "Check your mail for password";
		}
		map.put("msg", msg);
		return "info";
	}

	
	

}





