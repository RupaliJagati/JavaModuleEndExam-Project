package com.canteen.cntr;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//import com.canteen.service.DishesService;
import com.canteen.dto.Dishes;
import com.canteen.dto.User;
import com.canteen.service.DishesService;



@Controller
public class DishesController {
	@Autowired
	private DishesService dishesService;
	
	@RequestMapping(value = "/prep_dishes_add_form.htm",method = RequestMethod.GET)
	public String prepDishesAddForm(ModelMap map) {
		map.put("dishes", new Dishes());
		return "dishes_add_form";
	}
	
	@RequestMapping(value = "/dishes_add.htm",method = RequestMethod.POST)
	public String expenseAdd(Dishes dishes) {
		dishesService.addDishes(dishes);
		return "home";
	}
	@RequestMapping(value = "/dishes_list.htm",method = RequestMethod.GET)
	public String allDishes(ModelMap map,HttpSession session) {
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Dishes> li = dishesService.selectAll();
		map.put("dishList", li);
		return "dish_list";
	}
	
	@RequestMapping(value = "/dish_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int dishId,ModelMap map,HttpSession session) {
		
		dishesService.removeDishes(dishId);
		
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Dishes> li = dishesService.selectAll();
		map.put("dishList", li);
		return "dish_list";
	}
	
	@RequestMapping(value = "/dish_update_form.htm",method = RequestMethod.GET)
	public String dishesUpdateForm(@RequestParam int dishId,ModelMap map) {
		
		Dishes exp = dishesService.findDishes(dishId);
		map.put("dishes", exp);
		
		return "dish_update_form";
	}
	
	@RequestMapping(value = "/dishes_update.htm",method = RequestMethod.POST)
	public String dishesUpdate(Dishes dishes,ModelMap map,HttpSession session) {
		
		//int userId = ((User)session.getAttribute("user")).getUserId();
		//dishes.setUserId();
		dishesService.modifyDishes(dishes);
			
		List<Dishes> li = dishesService.selectAll();
		map.put("dishList", li);
		return "dish_list";
	}
	
}





	
	

