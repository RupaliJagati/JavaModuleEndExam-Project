package com.canteen.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.canteen.dao.SelectDishDao;
import com.canteen.dto.Dishes;
import com.canteen.dto.SelectDish;
import com.canteen.dto.User;
import com.canteen.service.DishesService;
import com.canteen.service.SelectDishService;

@Controller
public class SelectDishController {
	

	@Autowired
	private SelectDishService selectDishService;
	
	
	@Autowired
	//private SelectDishService selectDishService;
	private DishesService dishesService;
	
	 @RequestMapping(value="/add_to_dish.htm") 
	 public  String prepRegForm(@RequestParam int dishId,ModelMap map,HttpSession session,SelectDish selectDish) throws IOException{
	 System.out.println(" =========");
		 map.put("SelectDish", new SelectDish());
		 Dishes d = dishesService.findDishes(dishId);
	  
	  
		User userid = (User)session.getAttribute("user");
		 selectDish.setQuantity(1);
		 selectDish.setUser(userid); 
		 selectDish.setDish(d);
		 System.out.println(userid);
		 System.out.println(d);
		 System.out.println(selectDish);


		 	selectDishService.addDish(selectDish);
		 	
		
		 	List<Dishes> li = dishesService.selectAll();
			map.put("dishList", li);
			return "Home_List";
	  }
	 
	 
	 
	 @RequestMapping(value = "/get_Cart.htm",method = RequestMethod.GET)
		public String allExpenses(ModelMap map,HttpSession session) {
		 System.out.println("============================================================================");
		 int s = ((User) session.getAttribute("user")).getUserId();
			List<SelectDish> li = selectDishService.selectAllDish1(s);
			System.out.println(s);
			map.put("cartList", li);
			return "Final";
		}
	
}

